package test.android.eanative.nativeshowadsinlistview;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.Arrays;

import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import eanative.android.EANative;
import eanative.android.model.EANativeListAdapter;

public class MainActivity extends Activity {

    private ListView mainListView ;
    private ArrayAdapter<String> listAdapter ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainListView = (ListView) findViewById( R.id.mainListView );

        String[] planets = new String[] { "Mercury", "Venus", "Earth", "Mars",
                "Jupiter", "Saturn", "Uranus", "Neptune", "Ceres", "Pluto", "Haumea", "Eris"};

        ArrayList<String> planetList = new ArrayList<String>();
        planetList.addAll( Arrays.asList(planets) );

        listAdapter = new ArrayAdapter<String>(this, R.layout.simplerow, planetList);

        //mainListView.setAdapter(listAdapter);
        EANative.initialize(this, "eanative-test-key");
        EANativeListAdapter eaNativeAdapter = EANative.createListAdapter( this, listAdapter);
        mainListView.setAdapter(eaNativeAdapter);
        eaNativeAdapter.initPlacement("2061", R.layout.eanative_ad_view_sample_1);
    }
}
