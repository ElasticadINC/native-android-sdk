package test.android.eanative.nativeshowadsinview;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;

import eanative.android.EANative;
import eanative.android.ad.EANativeAdPlacer;
import eanative.android.events.EANativeEvent;
import eanative.android.events.EANativeEventListener;
import eanative.android.util.Logger;


public class MainActivity extends Activity {

    private EANativeAdPlacer adPlacer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EANative.initialize(this, "eanative-test-key");
        this.adPlacer = EANative.createAdPlacer(this);
        this.adPlacer.initPlacement("2061", R.layout.eanative_ad_view_sample_2);
        this.adPlacer.registerEventListener(EANativeEvent.ADS_LOADED,
                new EANativeEventListener() {
                    @Override
                    public void handleMessage(String event, Object message) {
                        MainActivity.this.adLoaded();
                    }
                });
        this.adPlacer.registerEventListener(EANativeEvent.AD_LOAD_ERROR,
                new EANativeEventListener() {
                    @Override
                    public void handleMessage(String event, Object message) {
                        Logger.info("APP: ERROR LOADING ADS %s",message);
                    }
                });
        this.adPlacer.requestAds();
    }

    protected void adLoaded(){
        //get the last loaded view
        View adView = this.adPlacer.getView(/* convertView */null,/*parentView*/(ViewGroup) this.getWindow().getDecorView().getRootView());
        this.addContentView(adView, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
    }


}
