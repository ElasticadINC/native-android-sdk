package com.mopub.common;

/**
 * A marker interface for 3rd party SDK options.
 */
public interface MediationSettings {}
