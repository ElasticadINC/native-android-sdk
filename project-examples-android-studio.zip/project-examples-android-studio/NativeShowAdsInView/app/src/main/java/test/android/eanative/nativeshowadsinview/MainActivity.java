package test.android.eanative.nativeshowadsinview;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;

import eanative.android.EANative;
import eanative.android.ad.EANativeAdPlacer;
import eanative.android.events.EANativeEvent;
import eanative.android.events.EANativeEventListener;
import eanative.android.model.EANativePlacementConfig;


public class MainActivity extends Activity {

    private EANativeAdPlacer adPlacer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EANative.initialize(this, "eanative-ednqxf3u-key");
        EANative.setTestMode(true, "5188c8b2c4993a5b");

        this.adPlacer = EANative.createAdPlacer(this);
        this.adPlacer.initPlacement("13126", R.layout.eanative_ad_view_sample_2);
        this.adPlacer.registerEventListener(EANativeEvent.ADS_LOADED,
                new EANativeEventListener() {
                    @Override
                    public void handleMessage(String event, Object message) {
                        MainActivity.this.adLoaded();
                    }
                });
        this.adPlacer.requestAds();
    }

    protected void adLoaded(){
        //get the last loaded view
        View adView = this.adPlacer.getView(/* convertView */null,/*parentView*/(ViewGroup) this.getWindow().getDecorView().getRootView());
        this.addContentView(adView, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
    }


}
