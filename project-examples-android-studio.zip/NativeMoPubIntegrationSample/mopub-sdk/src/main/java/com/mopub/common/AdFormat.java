package com.mopub.common;

public enum AdFormat {
    BANNER,
    INTERSTITIAL,
    NATIVE,
    REWARDED_VIDEO,
}
